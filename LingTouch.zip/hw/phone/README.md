# 鸿蒙手机端应用

ArkTS 原生应用（Stage 模型），承载语音交互、任务管理、点阵帧生成与设备连接。运行于 HarmonyOS 5.0.0(12) 及以上的手机与平板。

## 功能

| 能力 | 实现 | 系统能力 |
|---|---|---|
| Agent | `agent/Agent.ets`：口令 → 寻物 / 导航 / 模式切换 / 取消任务；协调眼镜感知、地图服务、手柄状态；选择语音或触觉反馈 | — |
| 口令解析 | 大模型解析（经手机端服务）为主，本地规则 `agent/RuleParser.ets` 兜底 | Network Kit |
| 反馈仲裁 | `agent/FeedbackArbiter.ets`：紧急提醒 > 导航指引 / 异常 / 确认 > 一般提示；紧急提醒解除后恢复导航播报 | — |
| 语音 | 离线语音识别与播报 | Core Speech Kit |
| 眼镜链路 | `perception/GlassesLink.ets`：WebSocket 接收感知 JSON，下发寻物检测词 | Network Kit |
| 点阵帧生成 | `frame/TactileFrame.ets`：40cm 全局帧、5cm 寻物帧、15 字节手柄帧 | — |
| 手柄链路 | `device/HandleLink.ets`：BLE 连接手柄，按刷新确认流控下发 | Connectivity Kit |
| 导航 | `nav/`：连续定位、百度步行路线、进度跟踪与语音指引、偏航重规划 | Location Kit、Map Kit |
| 界面 | `pages/Index.ets`：连接状态、模式、手柄点阵、最近播报、地图与导航信息、点按说话 | ArkUI、Map Kit |

## 交互

**全局感知**：眼镜的 40cm 占用栅格（纵向 1–5m、横向 ±1.8m）每个占用格左右各扩一列后镜像打包，下发到手柄。触点只有平、凸两档，凸起表示该处有障碍。

**语义寻物**：
1. 按手柄按键进入寻物模式，点阵全部落平，播报"请说要找的物品"并自动开始收音。也可以在任何时候直接说"找椅子"。
2. 目标词解析为英文检测短语下发给眼镜，点阵保持全平，语音引导方向与距离；首次发现时补充高度（地面或台面）。
3. 目标进入正前方一臂（0.8m）以内时切换为 5cm 网格，以目标为中心，只凸起最近那个目标的占地轮廓。
4. 一直没有发现时明确提示"没有找到"，并说明点阵全平不代表周围没有障碍。
5. 使用者摸到并确认后按键返回全局模式。

**导航与语音提醒**：说"去某地"→ 检索目的地、规划步行路线 → 语音确认后出发。导航期间触觉感知持续运行；来车等动态危险一律语音提醒并打断当前播报，解除后播报当前导航指引。改变目的地、偏航重规划、结束导航前都先语音确认。

**异常**：眼镜断开、无画面或找不到地面时保留上一帧 2 秒，之后点阵落平并语音提示"前方感知中断"，每 10 秒重复直到恢复。手柄断开时语音提示并自动重连。设备未连接时界面显示"未连接"。

**语音入口**：底部整条"点按说话"，停顿后自动结束收音，支持屏幕朗读。进入寻物模式、需要确认时自动开麦；来车提醒会打断收音，播报后自动重新开麦。

## 构建

需要 HarmonyOS SDK（DevEco Studio 或 Command Line Tools）。

```sh
hvigorw assembleHap --mode module -p product=default -p buildMode=debug --no-daemon
```

在 DevEco Studio 中打开本目录即可构建与安装。安装到设备前需在 `build-profile.json5` 中配置签名（DevEco Studio：项目结构 → Signing Configs）。

**Map Kit**：在 AppGallery Connect 为应用开通"地图服务"后重新申请调试 Profile 并签名。设备系统低于 HarmonyOS 5.0.2(14) 时，还需在 `entry/src/main/module.json5` 的 `module` 下增加：

```json5
"metadata": [{ "name": "client_id", "value": "<应用的 Client ID>" }]
```

## 使用

1. 启动眼镜端感知服务与手机端服务（见各自目录的 README）。
2. 打开应用，授予蓝牙、麦克风、位置权限。
3. 点击"设置"：填写眼镜感知服务地址（`ws://<IP>:8770/perception`）与手机端服务地址（`http://<IP>:3000`），保存；打开手柄电源，"搜索手柄"后点击"连接"。之后启动自动连接上次的手柄。

## 权限

| 权限 | 用途 |
|---|---|
| `ohos.permission.ACCESS_BLUETOOTH` | 连接触觉手柄 |
| `ohos.permission.MICROPHONE` | 语音口令 |
| `ohos.permission.LOCATION`、`APPROXIMATELY_LOCATION` | 步行导航定位 |
| `ohos.permission.INTERNET` | 眼镜链路、手机端服务 |
