# 灵触随行 源代码

面向视障用户的触觉空间感知系统。Agent 协调眼镜端感知、手机端寻物与导航，把环境布局和目标位置转化为可触摸的点阵，与语音协同帮助用户理解空间、自主出行。

```
┌──────────────┐  感知 JSON (WebSocket)  ┌──────────────────────┐   BLE 点阵帧   ┌──────────────┐
│   智能眼镜    │ ──────────────────────► │     鸿蒙手机 App      │ ─────────────► │   触觉手柄    │
│ 摄像头+激光雷达│ ◄────────────────────── │ Agent / 语音 / 点阵帧 │ ◄───────────── │ ESP32-S3     │
│ 深度估计+识别 │      寻物检测词          │ 导航 / 设备连接       │ 按键·刷新确认  │ 90 触点       │
└──────────────┘                          └──────────┬───────────┘                └──────────────┘
                                                     │ HTTP
                                          ┌──────────▼───────────┐
                                          │      手机端服务       │ ──► 百度地图开放平台
                                          │ 路线 / 口令解析        │ ──► 大模型（OpenAI 兼容接口）
                                          └──────────────────────┘
```

| 目录 | 内容 | 技术 |
|---|---|---|
| [glasses/](glasses/README.md) | 眼镜端感知服务：深度估计、激光雷达定尺度、地面拟合、40cm 占用栅格、开放词汇识别、来车检测，输出感知 JSON | Python、PyTorch |
| [phone/](phone/README.md) | 鸿蒙手机应用：Agent、语音交互、点阵帧生成、BLE、定位导航、Map Kit | ArkTS（HarmonyOS 5.0.0(12)+） |
| [server/](server/README.md) | 手机端服务：百度地图地点检索与步行路线、大模型口令解析 | Node.js |
| [firmware/](firmware/README.md) | 触觉手柄固件：BLE 收帧、595 + ULN 四阶段刷新、按键与刷新确认回传 | Arduino / ESP32-S3 |

## 核心能力与代码位置

| 能力 | 位置 |
|---|---|
| 深度估计与物体识别，JSON 传输感知结果 | `glasses/perception.py`、`glasses/link_server.py` |
| 激光雷达测距定尺度 | `glasses/lidar_tfs20l.py`、`glasses/scale_anchor.py` |
| 全局空间感知（40cm 网格，10×9 触点） | `glasses/ground_topdown.py` → `phone/.../frame/TactileFrame.ets` |
| 语义寻物（5cm 网格，未找到明确提示） | `glasses/object_detector.py`、`glasses/object_locator.py` → `phone/.../agent/Agent.ets` |
| 来车检测 | `glasses/hazard_tracker.py` |
| 步行导航与语音指引 | `server/services/baiduMap.js`、`phone/.../nav/` |
| 紧急提醒优先、解除后恢复导航 | `phone/.../agent/FeedbackArbiter.ets` |
| 关键操作语音确认 | `phone/.../agent/Agent.ets`（`ask` / `resolveConfirm`） |
| 口令解析为寻物、导航、模式切换任务 | `server/services/intentModel.js`、`phone/.../agent/RuleParser.ets` |
| 手柄按键切换模式、刷新确认 | `firmware/`、`phone/.../device/HandleLink.ets` |
| 感知或通信异常提示 | `phone/.../agent/Agent.ets`（`tick`） |

## 启动顺序

1. **眼镜端感知服务**：`cd glasses && pip install -r requirements.txt && python download_models.py`，复制 `config.example.json` 为 `config.json` 后 `python main.py`。
2. **手机端服务**：`cd server && npm ci`，复制 `.env.example` 为 `.env` 并填写密钥后 `npm start`。
3. **触觉手柄**：烧录 `firmware/braille_15module_prod`，上电后自动广播。
4. **手机应用**：构建安装 `phone/`，在"设置"中填写眼镜与服务地址、连接手柄。

眼镜、手机、服务处于同一局域网；手机端服务需要访问互联网（地图与大模型）。

## 第三方组件

| 组件 | 用途 | 许可证 |
|---|---|---|
| Depth Anything V2 Metric Hypersim Large | 米制深度估计 | 权重 CC-BY-NC-4.0，源码 Apache-2.0 |
| Grounding DINO Tiny | 开放词汇目标检测 | Apache-2.0 |
| 百度地图开放平台 Web 服务 API | 地点检索、步行路线规划 | 百度地图开放平台服务条款 |
| HarmonyOS Core Speech Kit / Map Kit / Location Kit / Connectivity Kit | 语音、地图、定位、蓝牙 | HarmonyOS SDK |
