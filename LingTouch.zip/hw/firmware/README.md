# 触觉手柄固件

ESP32-S3 经 SPI 驱动 16 级 74HC595 移位寄存器与 16 组 ULN 达林顿驱动，控制 15 个六点触觉模组，共 90 触点。手机经 BLE 下发点阵帧，手柄按四阶段时序刷新触点，并回传刷新确认与按键事件。

## 烧录

Arduino IDE 安装开发板支持 **esp32 by Espressif Systems**（3.x），开发板选择 **ESP32-S3 Dev Module**，打开 `braille_15module_prod/braille_15module_prod.ino` 编译烧录。也可以使用 arduino-cli：

```sh
arduino-cli compile --fqbn esp32:esp32:esp32s3 braille_15module_prod
arduino-cli upload  --fqbn esp32:esp32:esp32s3 -p <串口> braille_15module_prod
```

## 引脚

| 信号 | GPIO |
|---|---|
| SER（串行数据） | 11 |
| SRCLK（移位时钟） | 12 |
| RCLK（锁存） | 10 |
| OE#（输出使能，低有效） | 9 |
| SRCLR#（清零，低有效） | 8 |
| 按键（内部上拉，按下为低） | 6 |

## BLE 协议

设备名 `LingChu-Tactile`，服务 UUID `FFE0`。

| 特征 | 属性 | 内容 |
|---|---|---|
| `FFE1` | Write / Write Without Response | 15 字节点阵帧 |
| `FFE3` | Notify | 2 字节事件 `[类型, 数据]` |

**点阵帧**：第 m 字节（m = 0…14）对应模组 m，模组按 5 行 × 3 列排布（行 = m / 3，列 = m % 3），每个模组覆盖点阵的 2 行 × 3 列；字节低 6 位为该模组的 6 个触点，1 为凸起。

**事件**：

| 类型 | 含义 | 数据 |
|---|---|---|
| `0x01` | 本帧刷新完成 | 0 |
| `0x02` | 模式上报（连接建立时及串口 `mode` 命令） | 当前模式 |
| `0x04` | 按键按下 | 当前模式 |

## 刷新时序

每个模组驱动字节的 bit0–5 为触点线圈，bit6 为 SMA 解锁。收到新帧后 15 个模组同步执行四个阶段：

| 阶段 | 驱动 | 默认时长 |
|---|---|---|
| A 解锁 | 仅 SMA 通电 | 10 ms |
| B 升起 | SMA 与线圈同时通电 | 50 ms |
| C 稳定 | SMA 关闭，仅线圈通电 | 150 ms |
| D 全断 | 全部断电，触点由机构保持 | 10 ms |

全量刷新约 220 ms，完成后通知 `0x01`。刷新过程中收到新帧时立即全断并中止，转而刷新新帧；手机端据此一次只下发一帧，收到刷新完成后再下发下一帧。

## 串口命令

115200 波特率，输入 `help` 查看全部命令。

| 命令 | 作用 |
|---|---|
| `clear` | 全部复位 |
| `set N XX` | 位置 N（1–15）设为 0xXX |
| `row R XX` / `col C XX` | 整行（1–5）/ 整列（1–3）设为 0xXX |
| `refresh` | 按当前数据重新刷新 |
| `print` | 打印当前状态 |
| `mode` | 切换模式并通知手机 |
| `raw on` / `raw off` | 进入 / 退出二进制帧模式（每 15 字节为一帧） |
| `mask 0xNNNN` / `step N` / `timing A B C D` | 模组掩码、分组步长、四阶段时长 |
| `hold N XX [T]` | 位置 N 线圈按 0xXX 通电 T 秒（SMA 不动） |
| `ex N XX [C]` | 位置 N 按 0xXX 做 C 次解锁循环 |
| `stop` | 立即全部断电（不改点阵数据） |
