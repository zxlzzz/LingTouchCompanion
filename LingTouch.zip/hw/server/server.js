/**
 * 灵触随行 手机端服务
 *
 * 为鸿蒙手机应用提供百度地图步行导航与口令解析，第三方服务密钥只保存在本服务的 .env 中。
 */

require('dotenv').config();

const express = require('express');
const mapRouter = require('./routes/map');
const agentRouter = require('./routes/agent');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '64kb' }));

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    map: Boolean(process.env.BAIDU_AK),
    agent: Boolean(process.env.LLM_BASE_URL && process.env.LLM_API_KEY && process.env.LLM_MODEL),
  });
});

app.use('/api/map', mapRouter);
app.use('/api/agent', agentRouter);

app.use((req, res) => res.status(404).json({ error: '接口不存在' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || (err.name === 'TimeoutError' ? 504 : 500);
  console.error(`[${req.method} ${req.path}] ${err.message}`);
  res.status(status).json({ error: err.message || '服务内部错误' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`灵触随行服务已启动 http://0.0.0.0:${PORT}`);
});
