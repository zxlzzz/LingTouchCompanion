/**
 * 百度地图开放平台 Web 服务
 *
 * 地点检索（place/v2/search 圆形区域检索）与步行路线规划（directionlite/v1/walking）。
 * 输入输出坐标统一为 GCJ-02，与手机端定位转换后的坐标、Map Kit 地图坐标一致。
 */

const BASE = 'https://api.map.baidu.com';
const TIMEOUT_MS = 8000;

function ak() {
  const key = process.env.BAIDU_AK;
  if (!key) {
    const err = new Error('服务端未配置百度地图 AK');
    err.status = 503;
    throw err;
  }
  return key;
}

async function call(path, params) {
  const url = new URL(path, BASE);
  for (const [k, v] of Object.entries({ ...params, output: 'json', ak: ak() })) {
    url.searchParams.set(k, String(v));
  }
  const res = await fetch(url, { signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!res.ok) {
    const err = new Error(`地图服务请求失败 HTTP ${res.status}`);
    err.status = 502;
    throw err;
  }
  const data = await res.json();
  if (data.status !== 0) {
    const err = new Error(`地图服务错误 ${data.status}: ${data.message || ''}`);
    err.status = 502;
    throw err;
  }
  return data;
}

const latLng = (p) => `${p.lat},${p.lng}`;

/** 以当前位置为圆心检索目的地，按距离排序。 */
async function searchPlace(query, around, radius = 5000) {
  const data = await call('/place/v2/search', {
    query,
    location: latLng(around),
    radius,
    radius_limit: false,
    coord_type: 2, // 输入 GCJ-02
    ret_coordtype: 'gcj02ll',
    scope: 2,
    page_size: 5,
  });
  return (data.results || [])
    .filter((r) => r.location)
    .map((r) => ({
      name: r.name,
      address: r.address || '',
      lat: r.location.lat,
      lng: r.location.lng,
      distance: r.detail_info && r.detail_info.distance !== undefined ? Number(r.detail_info.distance) : null,
    }));
}

function parsePath(path) {
  if (Array.isArray(path)) {
    return path.map((p) => ({ lat: Number(p.lat), lng: Number(p.lng) }));
  }
  if (typeof path !== 'string' || !path) return [];
  return path
    .split(';')
    .map((pair) => pair.split(',').map(Number))
    .filter(([lng, lat]) => Number.isFinite(lng) && Number.isFinite(lat))
    .map(([lng, lat]) => ({ lat, lng }));
}

const stripTags = (s) => String(s || '').replace(/<[^>]+>/g, '').trim();

/** 步行路线，返回整理后的分段指引与折线。 */
async function walkingRoute(origin, destination) {
  const data = await call('/directionlite/v1/walking', {
    origin: latLng(origin),
    destination: latLng(destination),
    coord_type: 'gcj02',
    ret_coordtype: 'gcj02',
    steps_info: 1,
  });
  const route = data.result && data.result.routes && data.result.routes[0];
  if (!route) {
    const err = new Error('没有可用的步行路线');
    err.status = 404;
    throw err;
  }
  return {
    distance: Number(route.distance || 0),
    duration: Number(route.duration || 0),
    steps: (route.steps || []).map((s) => ({
      instruction: stripTags(s.instruction),
      distance: Number(s.distance || 0),
      duration: Number(s.duration || 0),
      direction: s.direction === undefined ? null : Number(s.direction),
      start: s.start_location ? { lat: Number(s.start_location.lat), lng: Number(s.start_location.lng) } : null,
      end: s.end_location ? { lat: Number(s.end_location.lat), lng: Number(s.end_location.lng) } : null,
      path: parsePath(s.path),
    })),
  };
}

module.exports = { searchPlace, walkingRoute };
