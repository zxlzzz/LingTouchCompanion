/**
 * 口令解析：调用 OpenAI 兼容 Chat Completions 接口，把用户口令解析为结构化意图。
 *
 * 模型地址、名称、密钥由环境变量配置，密钥只保存在服务端。
 * 手机端同时提交当前任务状态，模型结合上下文判断意图（例如导航中说出新目的地即为改变路线）。
 */

const INTENTS = ['find_object', 'navigate', 'switch_mode', 'cancel', 'confirm', 'deny', 'repeat', 'unknown'];

const SYSTEM_PROMPT = `你是视障辅助设备"灵触随行"的口令解析模块。设备由智能眼镜（深度估计与物体识别）、手机和触觉点阵手柄组成，支持三类任务：
1. 寻物：用户要找某个物体，例如"找椅子""帮我看看红色的杯子在哪"。
2. 导航：用户要步行去某个地点，例如"去图书馆""带我到最近的地铁站"。
3. 模式切换：在"全局"（触觉点阵显示周围障碍布局）与"寻物"之间切换。
另外还有：取消当前任务、对设备提问的确认（是/好的/确认）或否定（不/不用/算了）、重复上一条导航指引。

只输出一个 JSON 对象，不要输出其他文字。字段：
{
  "intent": "find_object" | "navigate" | "switch_mode" | "cancel" | "confirm" | "deny" | "repeat" | "unknown",
  "target_zh": 寻物目标的中文描述（仅 find_object），
  "target_en": 寻物目标的英文检测短语，小写名词短语，保留颜色等修饰，例如 "chair"、"red cup"（仅 find_object），
  "destination": 导航目的地的地点名称，去掉"去""带我到"等动词（仅 navigate），
  "mode": "global" | "find"（仅 switch_mode）
}
若设备正在等待确认，用户的肯定或否定回答分别解析为 confirm 或 deny。无法判断时输出 {"intent":"unknown"}。`;

function config() {
  const { LLM_BASE_URL, LLM_API_KEY, LLM_MODEL, LLM_TIMEOUT_MS } = process.env;
  if (!LLM_BASE_URL || !LLM_API_KEY || !LLM_MODEL) {
    const err = new Error('服务端未配置口令解析模型');
    err.status = 503;
    throw err;
  }
  return {
    url: `${LLM_BASE_URL.replace(/\/+$/, '')}/chat/completions`,
    key: LLM_API_KEY,
    model: LLM_MODEL,
    timeout: Number(LLM_TIMEOUT_MS) || 6000,
  };
}

function describeContext(ctx = {}) {
  const lines = [];
  lines.push(`当前模式：${ctx.mode === 'find' ? '寻物' : '全局'}`);
  if (ctx.findTarget) lines.push(`正在寻找：${ctx.findTarget}`);
  if (ctx.navDestination) lines.push(`正在导航前往：${ctx.navDestination}`);
  if (ctx.pendingQuestion) lines.push(`设备正在等待用户确认：${ctx.pendingQuestion}`);
  return lines.join('\n');
}

function extractJson(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(text.slice(start, end + 1));
  } catch {
    return null;
  }
}

function normalize(raw) {
  if (!raw || !INTENTS.includes(raw.intent)) return { intent: 'unknown' };
  const out = { intent: raw.intent };
  if (raw.intent === 'find_object') {
    const zh = String(raw.target_zh || '').trim();
    const en = String(raw.target_en || '').trim().toLowerCase();
    if (!zh || !en) return { intent: 'unknown' };
    Object.assign(out, { target_zh: zh, target_en: en });
  } else if (raw.intent === 'navigate') {
    const dest = String(raw.destination || '').trim();
    if (!dest) return { intent: 'unknown' };
    out.destination = dest;
  } else if (raw.intent === 'switch_mode') {
    if (!['global', 'find'].includes(raw.mode)) return { intent: 'unknown' };
    out.mode = raw.mode;
  }
  return out;
}

async function parseCommand(text, context) {
  const cfg = config();
  const res = await fetch(cfg.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.key}` },
    body: JSON.stringify({
      model: cfg.model,
      temperature: 0,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: `${describeContext(context)}\n用户口令：${text}` },
      ],
    }),
    signal: AbortSignal.timeout(cfg.timeout),
  });
  if (!res.ok) {
    const err = new Error(`口令解析模型请求失败 HTTP ${res.status}`);
    err.status = 502;
    throw err;
  }
  const data = await res.json();
  const content = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  return normalize(extractJson(String(content || '')));
}

module.exports = { parseCommand };
