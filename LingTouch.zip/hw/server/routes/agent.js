/**
 * 口令解析接口
 *
 * POST /api/agent/parse  {text, context:{mode, findTarget, navDestination, pendingQuestion}}
 * 返回 {intent, target_zh?, target_en?, destination?, mode?}
 */

const express = require('express');
const intentModel = require('../services/intentModel');

const router = express.Router();

router.post('/parse', async (req, res, next) => {
  try {
    const { text, context } = req.body || {};
    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: '需要 text' });
    }
    res.json(await intentModel.parseCommand(text.trim(), context || {}));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
