/**
 * 地图接口
 *
 * GET  /api/map/search?query=&lat=&lng=   以当前位置为中心检索目的地（GCJ-02）
 * POST /api/map/walk-route                 {origin:{lat,lng}, destination:{lat,lng}} 步行路线
 */

const express = require('express');
const baiduMap = require('../services/baiduMap');

const router = express.Router();

const isCoord = (p) => p && Number.isFinite(Number(p.lat)) && Number.isFinite(Number(p.lng));
const toCoord = (p) => ({ lat: Number(p.lat), lng: Number(p.lng) });

router.get('/search', async (req, res, next) => {
  try {
    const { query, lat, lng } = req.query;
    if (!query || !isCoord({ lat, lng })) {
      return res.status(400).json({ error: '需要 query、lat、lng' });
    }
    res.json({ places: await baiduMap.searchPlace(String(query), toCoord({ lat, lng })) });
  } catch (err) {
    next(err);
  }
});

router.post('/walk-route', async (req, res, next) => {
  try {
    const { origin, destination } = req.body || {};
    if (!isCoord(origin) || !isCoord(destination)) {
      return res.status(400).json({ error: '需要 origin 与 destination 坐标' });
    }
    res.json({ route: await baiduMap.walkingRoute(toCoord(origin), toCoord(destination)) });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
