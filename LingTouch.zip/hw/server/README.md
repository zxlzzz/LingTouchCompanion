# 手机端服务

为鸿蒙手机应用提供百度地图步行导航与口令解析。第三方服务密钥只保存在本服务的 `.env` 中，不进入手机应用。

## 运行

Node.js 18 及以上：

```sh
npm ci
cp .env.example .env      # 填写百度地图 AK 与大模型接口配置
npm start
```

默认监听 `0.0.0.0:3000`，在手机 App 的"设置"中填入 `http://<本机IP>:3000`。

## 配置（.env）

| 变量 | 说明 |
|---|---|
| `PORT` | 监听端口，默认 3000 |
| `BAIDU_AK` | 百度地图开放平台服务端 AK，需开通"地点检索"与"轻量级路线规划" |
| `LLM_BASE_URL` | 大模型 OpenAI 兼容接口地址，填到 `/v1` 为止 |
| `LLM_API_KEY` | 大模型接口密钥 |
| `LLM_MODEL` | 模型名称 |
| `LLM_TIMEOUT_MS` | 解析超时，默认 6000 |

## 接口

坐标统一为 GCJ-02（手机端由系统定位的 WGS-84 转换而来，与 Map Kit 地图一致）。

### `GET /api/health`

```json
{"ok": true, "map": true, "agent": true}
```

### `GET /api/map/search?query=图书馆&lat=39.99&lng=116.31`

以当前位置为中心（5km）检索目的地，调用百度地图地点检索（圆形区域检索）。

```json
{"places": [{"name": "…", "address": "…", "lat": 39.99, "lng": 116.31, "distance": 420}]}
```

### `POST /api/map/walk-route`

```json
{"origin": {"lat": 39.99, "lng": 116.31}, "destination": {"lat": 39.98, "lng": 116.32}}
```

调用百度地图轻量级步行路线规划，返回整理后的分段指引与折线：

```json
{"route": {"distance": 860, "duration": 700, "steps": [
  {"instruction": "从起点向正北方向出发,沿学院路走100米,右转", "distance": 100, "duration": 80,
   "direction": 0, "start": {"lat": 0, "lng": 0}, "end": {"lat": 0, "lng": 0}, "path": [{"lat": 0, "lng": 0}]}
]}}
```

### `POST /api/agent/parse`

```json
{"text": "帮我找红色的杯子", "context": {"mode": "global", "findTarget": "", "navDestination": "", "pendingQuestion": ""}}
```

调用大模型把口令解析为结构化意图；`context` 为手机当前任务状态，用于判断"导航中说出新地点 = 改变路线"、"等待确认时的回答"等。

```json
{"intent": "find_object", "target_zh": "红色的杯子", "target_en": "red cup"}
```

| intent | 附带字段 |
|---|---|
| `find_object` | `target_zh`、`target_en`（英文检测短语，传给眼镜端） |
| `navigate` | `destination` |
| `switch_mode` | `mode`：`global` / `find` |
| `cancel`、`confirm`、`deny`、`repeat`、`unknown` | — |

错误统一返回 `{"error": "…"}`：参数错误 400，服务未配置 503，上游失败 502，超时 504。手机端在解析接口不可用时使用本地规则解析。
