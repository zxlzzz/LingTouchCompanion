"""
来车检测：跨帧跟踪车辆类目标，按距离变化判断是否正在接近。

每类车辆的检测框逐帧按 IoU 关联成轨迹，轨迹保留最近一段时间的距离观测，
用最小二乘拟合距离随时间的变化率得到接近速度。接近速度超过阈值、且按当前速度
到达时间（TTC）低于阈值的轨迹作为危险上报。阈值高于正常步行速度，
使用者自身前行造成的静止车辆"接近"不会触发。
"""

import itertools
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from object_detector import box_iou


@dataclass
class HazardConfig:
    min_approach_mps: float = 2.5      # 接近速度阈值
    max_ttc_s: float = 4.0             # 到达时间阈值
    max_range_m: float = 20.0          # 超出此距离不跟踪
    window_s: float = 3.0              # 速度估计时间窗
    min_observations: int = 3
    min_span_s: float = 0.8
    track_timeout_s: float = 1.5
    iou_match: float = 0.2


@dataclass
class _Track:
    track_id: int
    label: str
    box: tuple
    last_t: float
    history: deque = field(default_factory=deque)     # (t, distance_m, bearing_deg)


class HazardTracker:
    def __init__(self, cfg=None):
        self.cfg = cfg or HazardConfig()
        self._tracks = []
        self._ids = itertools.count(1)

    def reset(self):
        self._tracks = []

    def update(self, t, observations):
        """observations: [(label, box, distance_m, bearing_deg)]，返回危险列表。"""
        cfg = self.cfg
        self._tracks = [tr for tr in self._tracks if t - tr.last_t <= cfg.track_timeout_s]
        free = list(self._tracks)
        for label, box, dist, bearing in sorted(observations, key=lambda o: o[2]):
            if dist > cfg.max_range_m:
                continue
            best, best_iou = None, cfg.iou_match
            for tr in free:
                if tr.label != label:
                    continue
                iou = box_iou(tr.box, box)
                if iou > best_iou:
                    best, best_iou = tr, iou
            if best is None:
                best = _Track(next(self._ids), label, box, t)
                self._tracks.append(best)
            else:
                free.remove(best)
            best.box, best.last_t = box, t
            best.history.append((t, dist, bearing))
            while best.history and t - best.history[0][0] > cfg.window_s:
                best.history.popleft()

        hazards = []
        for tr in self._tracks:
            if tr.last_t != t or len(tr.history) < cfg.min_observations:
                continue
            ts = np.array([h[0] for h in tr.history])
            ds = np.array([h[1] for h in tr.history])
            if ts[-1] - ts[0] < cfg.min_span_s:
                continue
            slope = np.polyfit(ts - ts[0], ds, 1)[0]
            approach = -float(slope)
            dist, bearing = tr.history[-1][1], tr.history[-1][2]
            if approach < cfg.min_approach_mps:
                continue
            ttc = dist / approach
            if ttc > cfg.max_ttc_s:
                continue
            hazards.append({
                "track_id": tr.track_id,
                "label": tr.label,
                "distance_m": round(dist, 2),
                "bearing_deg": round(bearing, 1),
                "approach_mps": round(approach, 2),
                "ttc_s": round(ttc, 2),
            })
        return hazards
