"""
下载眼镜端感知服务所需的模型权重到 models/。

默认经 https://hf-mirror.com 下载；设置环境变量 HF_ENDPOINT 可改用其他地址，
例如 HF_ENDPOINT=https://huggingface.co。已下载完成的文件会跳过，中断后重新运行
从断点继续。

    python download_models.py
"""

import os
import sys
import urllib.request
from pathlib import Path

ENDPOINT = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com").rstrip("/")
MODELS_DIR = Path(__file__).resolve().parent / "models"

MODELS = [
    # (仓库, 本地子目录, 文件列表)
    ("depth-anything/Depth-Anything-V2-Metric-Hypersim-Large", "",
     ["depth_anything_v2_metric_hypersim_vitl.pth"]),
    ("IDEA-Research/grounding-dino-tiny", "grounding-dino-tiny",
     ["config.json", "model.safetensors", "preprocessor_config.json",
      "special_tokens_map.json", "tokenizer.json", "tokenizer_config.json", "vocab.txt"]),
]


def fetch(url, dest):
    part = dest.with_name(dest.name + ".part")
    done = part.stat().st_size if part.exists() else 0
    req = urllib.request.Request(url, headers={"Range": f"bytes={done}-"} if done else {})
    with urllib.request.urlopen(req, timeout=60) as resp:
        if done and resp.status != 206:
            done = 0
        total = done + int(resp.headers.get("Content-Length") or 0)
        with open(part, "ab" if done else "wb") as f:
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    print(f"\r  {done / 1e6:8.1f} / {total / 1e6:.1f} MB", end="", flush=True)
    print()
    part.replace(dest)


def main():
    print(f"下载地址：{ENDPOINT}")
    for repo, subdir, files in MODELS:
        target = MODELS_DIR / subdir
        target.mkdir(parents=True, exist_ok=True)
        for name in files:
            dest = target / name
            if dest.exists():
                print(f"已存在  {repo}/{name}")
                continue
            print(f"下载    {repo}/{name}")
            fetch(f"{ENDPOINT}/{repo}/resolve/main/{name}", dest)
    print(f"完成，模型位于 {MODELS_DIR}")


if __name__ == "__main__":
    sys.exit(main())
