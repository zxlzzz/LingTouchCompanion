"""
单目米制深度估计（Depth Anything V2 Metric，ViT-L，室内 Hypersim 权重）。

输入 BGR 图像，输出与输入同尺寸的深度图（单位 m，沿相机光轴）。
模型常驻显存，服务启动时加载一次；CUDA 上以 fp16 推理。
"""

import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent / "third_party"))
from depth_anything_v2.dpt import DepthAnythingV2  # noqa: E402

_VITL = {"encoder": "vitl", "features": 256, "out_channels": [256, 512, 1024, 1024]}


class DepthEstimator:
    def __init__(self, checkpoint, device, input_size=518, max_depth=20.0):
        self.device = device
        self.input_size = input_size
        checkpoint = Path(checkpoint)
        if not checkpoint.exists():
            raise FileNotFoundError(f"深度模型权重不存在：{checkpoint}，请先运行 download_models.py")
        model = DepthAnythingV2(**_VITL, max_depth=max_depth)
        model.load_state_dict(torch.load(str(checkpoint), map_location="cpu"))
        self.model = model.to(device).eval()

    @torch.no_grad()
    def infer(self, bgr):
        image, (h, w) = self.model.image2tensor(bgr, self.input_size)
        with torch.autocast("cuda", dtype=torch.float16, enabled=self.device.startswith("cuda")):
            depth = self.model(image.to(self.device))
        depth = F.interpolate(depth[:, None], (h, w), mode="bilinear", align_corners=True)[0, 0]
        return depth.float().cpu().numpy().astype(np.float32)
