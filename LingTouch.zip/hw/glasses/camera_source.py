"""
相机输入。

所有相机源实现同一接口：start() 启动采集，latest() 返回最近一帧 (BGR 图像, 采集时刻)，
无画面时返回 None。支持三种来源：

  usb        本机 USB / UVC 摄像头
  mjpeg      网络 MJPEG 图像流（HTTP multipart）
  websocket  图像流经 WebSocket 推送到本服务的 /camera 路径，每条二进制消息为一帧 JPEG

取到的画面统一做旋转与长边缩放，与标定焦距时的画面方向、分辨率基准一致。
"""

import logging
import threading
import time

import cv2
import numpy as np

log = logging.getLogger("camera")

_ROTATIONS = {
    0: None,
    90: cv2.ROTATE_90_CLOCKWISE,
    180: cv2.ROTATE_180,
    270: cv2.ROTATE_90_COUNTERCLOCKWISE,
}


class FrameSource:
    def __init__(self, rotate_deg=0, max_side_px=2048):
        if rotate_deg not in _ROTATIONS:
            raise ValueError("rotate_deg 只能是 0/90/180/270")
        self._rotate = _ROTATIONS[rotate_deg]
        self._max_side = max_side_px
        self._lock = threading.Lock()
        self._frame = None
        self._stop = threading.Event()

    def _prepare(self, bgr):
        if self._rotate is not None:
            bgr = cv2.rotate(bgr, self._rotate)
        scale = self._max_side / max(bgr.shape[:2])
        if scale < 1:
            bgr = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        return bgr

    def _publish(self, bgr):
        frame = (self._prepare(bgr), time.time())
        with self._lock:
            self._frame = frame

    def latest(self):
        with self._lock:
            return self._frame

    def start(self):
        return self

    def stop(self):
        self._stop.set()


class _CaptureSource(FrameSource):
    """基于 cv2.VideoCapture 的持续采集，断开后自动重连。"""

    def __init__(self, target, name, **kw):
        super().__init__(**kw)
        self._target = target
        self._name = name
        self._thread = threading.Thread(target=self._run, name=name, daemon=True)

    def _open(self):
        return cv2.VideoCapture(self._target)

    def start(self):
        self._thread.start()
        return self

    def _run(self):
        while not self._stop.is_set():
            cap = self._open()
            if not cap.isOpened():
                log.warning("%s 无法打开，1 秒后重试", self._name)
                self._stop.wait(1.0)
                continue
            log.info("%s 已连接", self._name)
            while not self._stop.is_set():
                ok, bgr = cap.read()
                if not ok:
                    log.warning("%s 读取中断，重新连接", self._name)
                    break
                self._publish(bgr)
            cap.release()


class UsbCamera(_CaptureSource):
    def __init__(self, index=0, width=None, height=None, **kw):
        super().__init__(index, f"USB 摄像头 {index}", **kw)
        self._size = (width, height)

    def _open(self):
        cap = cv2.VideoCapture(self._target)
        if self._size[0] and self._size[1]:
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._size[0])
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._size[1])
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return cap


class MjpegStream(_CaptureSource):
    def __init__(self, url, **kw):
        super().__init__(url, f"MJPEG 图像流 {url}", **kw)


class WebSocketFrames(FrameSource):
    """由 link_server 在 /camera 路径收到的 JPEG 帧。"""

    def push_jpeg(self, data):
        bgr = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
        if bgr is not None:
            self._publish(bgr)


def create_source(cfg):
    kind = cfg["source"]
    common = dict(rotate_deg=cfg.get("rotate_deg", 0), max_side_px=cfg.get("max_side_px", 2048))
    if kind == "usb":
        return UsbCamera(cfg.get("usb_index", 0), cfg.get("usb_width"), cfg.get("usb_height"), **common)
    if kind == "mjpeg":
        return MjpegStream(cfg["mjpeg_url"], **common)
    if kind == "websocket":
        return WebSocketFrames(**common)
    raise ValueError(f"未知相机源：{kind}")
