"""
开放词汇目标检测（Grounding DINO）。

以自然语言短语作为检测类别，同一次推理同时检测寻物目标词与来车类别。
返回图像像素坐标下的检测框（同一短语内做非极大值抑制），框内的三维位置由深度图
另行计算。CUDA 上以 fp16 推理。
"""

from dataclasses import dataclass
from pathlib import Path

import cv2
import torch
from PIL import Image
from transformers import AutoModelForZeroShotObjectDetection, AutoProcessor


NMS_IOU = 0.5


def box_iou(a, b):
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


@dataclass
class Detection:
    phrase: str                 # 命中的检测短语
    score: float
    box: tuple                  # (u0, v0, u1, v1) 像素


class ObjectDetector:
    def __init__(self, model_dir, device, box_threshold=0.35, text_threshold=0.25):
        model_dir = Path(model_dir)
        if not model_dir.exists():
            raise FileNotFoundError(f"检测模型不存在：{model_dir}，请先运行 download_models.py")
        self.device = device
        self.box_threshold = box_threshold
        self.text_threshold = text_threshold
        self.processor = AutoProcessor.from_pretrained(model_dir)
        self.model = AutoModelForZeroShotObjectDetection.from_pretrained(model_dir).to(device).eval()

    @staticmethod
    def _match_phrase(text_label, phrases):
        """模型输出的是提示词中的片段，映射回完整短语。"""
        text_label = text_label.strip().lower()
        if not text_label:
            return None
        for p in phrases:
            if text_label == p:
                return p
        for p in phrases:
            if text_label in p or p in text_label:
                return p
        return None

    @torch.no_grad()
    def detect(self, bgr, phrases):
        phrases = [p.strip().lower() for p in phrases if p and p.strip()]
        if not phrases:
            return []
        image = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        inputs = self.processor(images=image, text=[phrases], return_tensors="pt").to(self.device)
        with torch.autocast("cuda", dtype=torch.float16, enabled=self.device.startswith("cuda")):
            outputs = self.model(**inputs)
        result = self.processor.post_process_grounded_object_detection(
            outputs, inputs.input_ids,
            threshold=self.box_threshold, text_threshold=self.text_threshold,
            target_sizes=[image.size[::-1]])[0]

        detections = []
        for score, box, label in zip(result["scores"], result["boxes"], result["text_labels"]):
            phrase = self._match_phrase(label, phrases)
            if phrase is None:
                continue
            u0, v0, u1, v1 = (float(x) for x in box.tolist())
            detections.append(Detection(phrase, float(score), (u0, v0, u1, v1)))

        kept = []
        for det in sorted(detections, key=lambda d: d.score, reverse=True):
            if all(k.phrase != det.phrase or box_iou(k.box, det.box) < NMS_IOU for k in kept):
                kept.append(det)
        return kept
