"""
深度尺度锚定。

单目深度的绝对尺度会随场景材质、光照漂移，每帧用一个物理测量量重新定尺度：

1. 激光雷达锚定（scale_source = "lidar"）
   激光雷达与相机光轴平行安装，光斑落在画面中心附近。取光斑覆盖的像素区域内
   深度中位数 d_img，尺度 s = 雷达测距 / d_img。
2. 佩戴高度锚定（scale_source = "camera_height"）
   雷达未接入或读数无效时，先在原始深度上拟合地面得到相机离地高度 h_img，
   尺度 s = 佩戴高度 / h_img。

两种方式都在乘以尺度后的深度上重新拟合地面，得到最终的地面坐标系。
"""

import math
from dataclasses import dataclass

import numpy as np

from ground_topdown import backproject, fit_ground
from lidar_tfs20l import FOV_DEG

SCALE_RANGE = (0.3, 3.0)        # 合理尺度区间，超出说明光斑与画面对应关系失效


@dataclass
class ScaleResult:
    depth: np.ndarray           # 已乘尺度的深度图
    scale: float
    source: str                 # lidar | camera_height
    lidar_status: str
    lidar_range_m: float


def _lidar_patch_depth(depth, K, offset_px):
    """光斑区域的深度中位数。光斑半径按雷达视场角换算为像素。"""
    H, W = depth.shape
    radius = max(4, int(math.tan(math.radians(FOV_DEG / 2)) * K.fx))
    u = int(K.cx + offset_px[0])
    v = int(K.cy + offset_px[1])
    patch = depth[max(0, v - radius):min(H, v + radius + 1),
                  max(0, u - radius):min(W, u + radius + 1)]
    patch = patch[np.isfinite(patch) & (patch > 0.1)]
    return float(np.median(patch)) if patch.size else None


def anchor_scale(depth, K, cfg, wearing_height_m, lidar, lidar_offset_px, rng):
    reading = lidar.latest() if lidar is not None else None
    lidar_status = reading.status if reading is not None else "not_connected"
    lidar_range = reading.distance_m if reading is not None else None

    if lidar_status == "ok":
        d_img = _lidar_patch_depth(depth, K, lidar_offset_px)
        if d_img is not None:
            s = reading.distance_m / d_img
            if SCALE_RANGE[0] <= s <= SCALE_RANGE[1]:
                return ScaleResult(depth * s, s, "lidar", lidar_status, lidar_range)
        lidar_status = "out_of_range"

    pts, _, vs = backproject(depth, K, cfg.stride)
    plane = fit_ground(pts, vs, depth.shape[0], cfg, rng)
    s = wearing_height_m / plane.camera_height
    return ScaleResult(depth * s, s, "camera_height", lidar_status, lidar_range)
