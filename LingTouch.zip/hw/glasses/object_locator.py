"""
检测框 -> 地面坐标系下的三维位置与 5cm 占地轮廓。

框内像素按深度分离前景：以框中心区域的深度中位数为物体深度，只保留与之接近的点，
去掉框内露出的背景与桌面。保留点投到地面坐标系，得到物体中心、离地高度范围，
以及按 5cm 网格统计的占地轮廓（寻物点阵的数据来源）。
"""

import math
from dataclasses import dataclass

import numpy as np

from ground_topdown import backproject

FOOTPRINT_CELL_M = 0.05
FOOTPRINT_MAX_CELLS = 60        # 轮廓单边上限（3m）
MIN_POINTS = 12


@dataclass
class ObjectLocation:
    x_m: float                  # 横向，右为正
    z_m: float                  # 前向
    distance_m: float
    bearing_deg: float          # 右为正
    bottom_m: float             # 最低点离地高度
    top_m: float                # 最高点离地高度
    footprint: dict = None


def _footprint(lat, fwd):
    ix = np.floor(lat / FOOTPRINT_CELL_M).astype(int)
    iz = np.floor(fwd / FOOTPRINT_CELL_M).astype(int)
    ix0, iz0 = int(ix.min()), int(iz.min())
    cols = min(int(ix.max()) - ix0 + 1, FOOTPRINT_MAX_CELLS)
    rows = min(int(iz.max()) - iz0 + 1, FOOTPRINT_MAX_CELLS)
    ok = (ix - ix0 < cols) & (iz - iz0 < rows)
    counts = np.zeros((rows, cols), dtype=int)
    np.add.at(counts, (iz[ok] - iz0, ix[ok] - ix0), 1)
    occupied = counts >= 2
    return {
        "cell_m": FOOTPRINT_CELL_M,
        "x0_m": round(ix0 * FOOTPRINT_CELL_M, 3),
        "z0_m": round(iz0 * FOOTPRINT_CELL_M, 3),
        "cols": cols,
        "rows": rows,
        # 行 0 为最远，与全局栅格方向一致
        "cells": ["".join("1" if v else "0" for v in row) for row in occupied[::-1]],
    }


def locate(depth, K, plane, box, with_footprint):
    u0, v0, u1, v1 = box
    bw, bh = u1 - u0, v1 - v0
    if bw < 4 or bh < 4:
        return None

    H, W = depth.shape
    cu0, cu1 = int(u0 + bw * 0.25), int(u1 - bw * 0.25)
    cv0, cv1 = int(v0 + bh * 0.25), int(v1 - bh * 0.25)
    core = depth[max(0, cv0):min(H, cv1 + 1), max(0, cu0):min(W, cu1 + 1)]
    core = core[np.isfinite(core) & (core > 0.1)]
    if core.size == 0:
        return None
    d_obj = float(np.median(core))

    stride = max(2, int(min(bw, bh) / 48))
    region = (u0 + bw * 0.05, v0 + bh * 0.05, u1 - bw * 0.05, v1 - bh * 0.05)
    pts, _, _ = backproject(depth, K, stride, region)
    if len(pts) == 0:
        return None
    pts = pts[np.abs(pts[:, 2] - d_obj) < max(0.2, 0.12 * d_obj)]
    if len(pts) < MIN_POINTS:
        return None

    fwd, lat, h = plane.to_ground(pts)
    x, z = float(np.median(lat)), float(np.median(fwd))
    return ObjectLocation(
        x_m=x, z_m=z,
        distance_m=math.hypot(x, z),
        bearing_deg=math.degrees(math.atan2(x, z)),
        bottom_m=max(0.0, float(np.percentile(h, 5))),
        top_m=max(0.0, float(np.percentile(h, 95))),
        footprint=_footprint(lat, fwd) if with_footprint else None,
    )
