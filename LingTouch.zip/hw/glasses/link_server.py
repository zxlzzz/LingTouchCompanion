"""
眼镜端与手机的无线链路（WebSocket）。

  /perception  手机连接此路径。连接后先收到 hello，之后每处理完一帧收到一条 perception；
               手机发送 {"type": "query", "targets": [...]} 设置寻物检测词，空数组为清除。
  /camera      相机源为 websocket 时，图像流推送到此路径，每条二进制消息为一帧 JPEG。

所有手机断开后自动清除检测词。
"""

import asyncio
import json
import logging

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

log = logging.getLogger("link")


class LinkServer:
    def __init__(self, host, port, hello, on_targets, frame_sink=None):
        self.host = host
        self.port = port
        self._hello = hello
        self._on_targets = on_targets
        self._frame_sink = frame_sink
        self._phones = set()
        self._loop = None

    async def _handle_phone(self, ws):
        self._phones.add(ws)
        log.info("手机已连接 %s", ws.remote_address)
        try:
            await ws.send(json.dumps(self._hello, ensure_ascii=False))
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except (TypeError, ValueError):
                    continue
                if msg.get("type") == "query" and isinstance(msg.get("targets"), list):
                    targets = [str(t) for t in msg["targets"]]
                    log.info("检测词：%s", targets or "（清除）")
                    self._on_targets(targets)
        except ConnectionClosed:
            pass
        finally:
            self._phones.discard(ws)
            log.info("手机已断开 %s", ws.remote_address)
            if not self._phones:
                self._on_targets([])

    async def _handle_camera(self, ws):
        log.info("图像流已接入 %s", ws.remote_address)
        try:
            async for data in ws:
                if isinstance(data, bytes):
                    self._frame_sink.push_jpeg(data)
        except ConnectionClosed:
            pass
        log.info("图像流已断开 %s", ws.remote_address)

    async def _route(self, ws):
        path = ws.request.path.split("?")[0]
        if path == "/perception":
            await self._handle_phone(ws)
        elif path == "/camera" and self._frame_sink is not None:
            await self._handle_camera(ws)
        else:
            await ws.close(code=1008, reason="unknown path")

    async def _broadcast(self, text):
        for ws in list(self._phones):
            try:
                await ws.send(text)
            except ConnectionClosed:
                self._phones.discard(ws)

    def publish(self, message):
        """供感知线程调用：把一条消息发给所有已连接的手机。"""
        if self._loop is None:
            return
        text = json.dumps(message, ensure_ascii=False, separators=(",", ":"))
        asyncio.run_coroutine_threadsafe(self._broadcast(text), self._loop)

    async def serve_forever(self):
        self._loop = asyncio.get_running_loop()
        async with serve(self._route, self.host, self.port, max_size=8 * 1024 * 1024):
            log.info("感知服务监听 ws://%s:%d/perception", self.host, self.port)
            await asyncio.Future()
