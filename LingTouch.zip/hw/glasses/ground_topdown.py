"""
地面拟合与俯视占用栅格。

米制深度图反投影为相机坐标系点云（x 右、y 下、z 前），在画面底部的近处点中
用 RANSAC + 非对称迭代精修拟合地面平面，得到地面坐标系：
    forward  相机光轴在地面上的投影方向
    lateral  地面内指向画面右侧
    height   离地高度

全局占用栅格为 10 行 × 9 列、每格 40cm：纵向 1–5m，横向 −1.8m–+1.8m，
行 0 为最远（4.6–5.0m）、行 9 为最近（1.0–1.4m），列 0 为最左。
每格的判定阈值按"该格被障碍物完全填满时应有的采样点数"乘填充比例得到，
因此与图像分辨率、采样步长无关；每列只保留最近的两个占用格，形成距离剖面。
"""

from dataclasses import dataclass

import numpy as np

GRID_ROWS = 10
GRID_COLS = 9
CELL_M = 0.4


@dataclass(frozen=True)
class TopdownConfig:
    stride: int = 8                  # 反投影像素采样步长
    h_min: float = 0.10              # 障碍高度下限(m)，低于此视为地面
    h_max: float = 1.80              # 障碍高度上限(m)
    d_min: float = 1.0               # 栅格纵向起点(m)
    d_max: float = 5.0               # 栅格纵向终点(m)
    lateral_half_m: float = 1.8      # 栅格横向半宽(m)
    ground_img_frac: float = 0.25    # 地面候选取画面底部的比例
    ground_d_max: float = 6.0        # 地面候选最远距离(m)
    ransac_iters: int = 300
    ransac_tol: float = 0.05         # RANSAC 内点容差(m)
    refit_low: float = -0.15         # 精修保留残差下限(m)，容忍地面起伏
    refit_high: float = 0.05         # 精修保留残差上限(m)，剔除贴地物体
    refit_rounds: int = 3
    occ_fill_frac: float = 0.035     # 占据判定的填充比例
    occ_min: int = 8                 # 占据判定的最少点数
    min_visible_m: float = 0.10      # 格子在视场内可见宽度低于此值时不判定
    max_cells_per_col: int = 2       # 每列保留的最近占用格数


class GroundNotFound(RuntimeError):
    """画面中没有足够的可见地面，本帧不能生成可靠的空间信息。"""


@dataclass
class Intrinsics:
    fx: float
    fy: float
    cx: float
    cy: float


@dataclass
class GroundPlane:
    normal: np.ndarray      # 单位法向，指向相机一侧（向上）
    d: float                # 平面方程 normal·p + d = 0
    forward: np.ndarray     # 地面坐标系前向单位向量（相机系）
    right: np.ndarray       # 地面坐标系右向单位向量（相机系）
    camera_height: float    # 相机离地高度(m)
    pitch_deg: float        # 相机俯仰角
    inlier_frac: float

    def to_ground(self, pts):
        """相机系点 (N,3) -> (forward, lateral, height)。"""
        return pts @ self.forward, pts @ self.right, pts @ self.normal + self.d


def backproject(depth, K, stride, region=None):
    """深度图按步长采样反投影。region=(u0, v0, u1, v1) 时只处理该像素矩形。

    返回 (pts(N,3), us(N,), vs(N,))。
    """
    H, W = depth.shape
    u0, v0, u1, v1 = region if region is not None else (0, 0, W, H)
    u0, v0 = max(0, int(u0)), max(0, int(v0))
    u1, v1 = min(W, int(u1)), min(H, int(v1))
    vs, us = np.mgrid[v0:v1:stride, u0:u1:stride]
    vs, us = vs.ravel(), us.ravel()
    z = depth[vs, us]
    ok = np.isfinite(z) & (z > 0.1) & (z < 30.0)
    us, vs, z = us[ok], vs[ok], z[ok]
    x = (us - K.cx) * z / K.fx
    y = (vs - K.cy) * z / K.fy
    return np.stack([x, y, z], axis=1), us, vs


def _plane_from_points(points):
    """最小二乘平面：协方差最小特征值方向为法向，法向朝上（相机系 −y）。"""
    c = points.mean(axis=0)
    dif = points - c
    _, vecs = np.linalg.eigh(dif.T @ dif)
    n = vecs[:, 0]
    if n[1] > 0:
        n = -n
    return n, -float(n @ c)


def fit_ground(pts, vs, img_h, cfg, rng):
    """在画面底部近处点中拟合地面平面。"""
    cand = pts[(vs > img_h * (1 - cfg.ground_img_frac)) & (pts[:, 2] < cfg.ground_d_max)]
    if len(cand) < 100:
        raise GroundNotFound("画面底部可见地面不足")

    best_n, best_d, best_cnt = None, 0.0, -1
    for _ in range(cfg.ransac_iters):
        p0, p1, p2 = cand[rng.choice(len(cand), 3, replace=False)]
        n = np.cross(p1 - p0, p2 - p0)
        nn = np.linalg.norm(n)
        if nn < 1e-9:
            continue
        n = n / nn
        if n[1] > 0:
            n = -n
        if -n[1] < 0.7:          # 与竖直方向夹角超过约 45° 的平面（墙面）不作地面
            continue
        d = -float(n @ p0)
        cnt = int(np.count_nonzero(np.abs(cand @ n + d) < cfg.ransac_tol))
        if cnt > best_cnt:
            best_n, best_d, best_cnt = n, d, cnt
    if best_n is None:
        raise GroundNotFound("未找到地面平面")

    inl = cand[np.abs(cand @ best_n + best_d) < cfg.ransac_tol]
    if len(inl) < 3:
        raise GroundNotFound("地面内点不足")
    n, d = _plane_from_points(inl)

    # 非对称迭代精修：地面以下容忍起伏，地面以上严格剔除，避免椅子腿等贴地物体抬高平面
    for _ in range(cfg.refit_rounds):
        resid = cand @ n + d
        nxt = cand[(resid > cfg.refit_low) & (resid < cfg.refit_high)]
        if len(nxt) < 50:
            break
        n, d = _plane_from_points(nxt)
        inl = nxt

    z_cam = np.array([0.0, 0.0, 1.0])
    fwd = z_cam - (z_cam @ n) * n
    fwd /= np.linalg.norm(fwd)
    right = np.cross(fwd, n)
    right /= np.linalg.norm(right)
    if right[0] < 0:
        right = -right
    pitch = float(np.degrees(np.arcsin(np.clip(-n[2], -1, 1))))
    return GroundPlane(normal=n, d=d, forward=fwd, right=right, camera_height=abs(d),
                       pitch_deg=pitch, inlier_frac=len(inl) / len(cand))


def occupancy_grid(fwd, lat, height, K, img_w, cfg):
    """地面坐标点 -> 10×9 占用栅格（bool，行 0 最远）。"""
    rows_edge = np.linspace(cfg.d_min, cfg.d_max, GRID_ROWS + 1)
    cols_edge = np.linspace(-cfg.lateral_half_m, cfg.lateral_half_m, GRID_COLS + 1)

    keep = ((height > cfg.h_min) & (height < cfg.h_max)
            & (fwd > cfg.d_min) & (fwd < cfg.d_max)
            & (np.abs(lat) < cfg.lateral_half_m))
    r = np.clip(((fwd[keep] - cfg.d_min) / CELL_M).astype(int), 0, GRID_ROWS - 1)
    c = np.clip(((lat[keep] + cfg.lateral_half_m) / CELL_M).astype(int), 0, GRID_COLS - 1)
    counts = np.zeros((GRID_ROWS, GRID_COLS), dtype=int)   # 此处行 0 最近
    np.add.at(counts, (r, c), 1)

    # 预期点数：格子在视场内的可见宽度 × 高度区间，在该距离上张开的像素面积
    z = (rows_edge[:-1] + rows_edge[1:]) / 2
    half_view = z * (img_w / 2) / K.fx
    lo = np.maximum(cols_edge[None, :-1], -half_view[:, None])
    hi = np.minimum(cols_edge[None, 1:], half_view[:, None])
    visible_w = np.clip(hi - lo, 0, None)
    px_w = visible_w * K.fx / z[:, None]
    px_h = (cfg.h_max - cfg.h_min) * K.fy / z[:, None]
    expected = px_w * px_h / (cfg.stride ** 2)
    thresh = np.maximum(expected * cfg.occ_fill_frac, cfg.occ_min)
    thresh[visible_w < cfg.min_visible_m] = np.inf

    passed = counts >= thresh
    grid = np.zeros_like(passed)
    for col in range(GRID_COLS):
        hit = np.nonzero(passed[:, col])[0][:cfg.max_cells_per_col]
        grid[hit, col] = True
    return grid[::-1].copy()
