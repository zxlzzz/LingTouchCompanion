"""
眼镜端感知管线：一帧图像 -> 一条感知 JSON。

流程：
  深度估计 -> 尺度锚定（激光雷达 / 佩戴高度）-> 地面拟合 -> 40cm 全局占用栅格
  -> 开放词汇检测（寻物目标词 + 来车类别）-> 目标三维定位与 5cm 占地轮廓
  -> 来车跨帧跟踪
地面拟合失败或相机无画面时输出 valid=false 的消息，只带状态，不带空间信息。
"""

import threading
import time

import numpy as np

from ground_topdown import (CELL_M, GRID_COLS, GRID_ROWS, GroundNotFound, Intrinsics,
                            TopdownConfig, backproject, fit_ground, occupancy_grid)
from hazard_tracker import HazardConfig, HazardTracker
from object_locator import locate
from scale_anchor import anchor_scale

PROTOCOL_VERSION = 1

# 检测短语 -> 上报的来车类别
HAZARD_PHRASES = {
    "car": "car",
    "bus": "car",
    "truck": "car",
    "motorcycle": "motorcycle",
    "bicycle": "bicycle",
    "electric scooter": "electric_bike",
    "electric bike": "electric_bike",
}
HAZARD_LABELS = sorted(set(HAZARD_PHRASES.values()))


def hello_message():
    return {"type": "hello", "version": PROTOCOL_VERSION, "hazard_labels": HAZARD_LABELS}


def _status(camera, depth, scale_source=None, lidar="not_connected", lidar_range=None):
    status = {"camera": camera, "depth": depth, "lidar": lidar}
    if scale_source:
        status["scale_source"] = scale_source
    if lidar_range is not None:
        status["lidar_range_m"] = round(lidar_range, 3)
    return status


class PerceptionPipeline:
    def __init__(self, depth_estimator, detector, lidar, camera_cfg, wearing_height_m,
                 lidar_offset_px=(0, 0), hazard_cfg=None, topdown_cfg=None):
        self.depth_estimator = depth_estimator
        self.detector = detector
        self.lidar = lidar
        self.fx_px = camera_cfg["fx_px"]
        self.fx_ref_width = camera_cfg["fx_ref_width_px"]
        self.wearing_height_m = wearing_height_m
        self.lidar_offset_px = lidar_offset_px
        self.cfg = topdown_cfg or TopdownConfig()
        self.tracker = HazardTracker(hazard_cfg or HazardConfig())
        self.rng = np.random.default_rng(0)
        self._seq = 0
        self._targets = []
        self._lock = threading.Lock()

    def set_targets(self, targets):
        with self._lock:
            self._targets = [t.strip().lower() for t in targets if t and t.strip()]

    def _next_seq(self):
        self._seq += 1
        return self._seq

    def _intrinsics(self, width, height):
        fx = self.fx_px * width / self.fx_ref_width
        return Intrinsics(fx=fx, fy=fx, cx=width / 2, cy=height / 2)

    def _lidar_status(self):
        if self.lidar is None:
            return "not_connected", None
        reading = self.lidar.latest()
        return reading.status, reading.distance_m

    def no_signal_message(self):
        lidar, lidar_range = self._lidar_status()
        return {
            "type": "perception", "seq": self._next_seq(),
            "ts": int(time.time() * 1000), "latency_ms": 0, "valid": False,
            "status": _status("no_signal", "invalid", lidar=lidar, lidar_range=lidar_range),
        }

    def process(self, bgr, captured_at):
        """captured_at 为采集时刻（time.time()）。"""
        with self._lock:
            targets = list(self._targets)
        H, W = bgr.shape[:2]
        K = self._intrinsics(W, H)
        msg = {"type": "perception", "seq": self._next_seq(), "ts": int(captured_at * 1000)}

        depth_raw = self.depth_estimator.infer(bgr)
        try:
            scaled = anchor_scale(depth_raw, K, self.cfg, self.wearing_height_m,
                                  self.lidar, self.lidar_offset_px, self.rng)
            pts, _, vs = backproject(scaled.depth, K, self.cfg.stride)
            plane = fit_ground(pts, vs, H, self.cfg, self.rng)
        except GroundNotFound:
            lidar, lidar_range = self._lidar_status()
            self.tracker.reset()
            msg.update(latency_ms=int((time.time() - captured_at) * 1000), valid=False,
                       status=_status("ok", "ground_not_found", lidar=lidar, lidar_range=lidar_range))
            return msg

        fwd, lat, height = plane.to_ground(pts)
        grid = occupancy_grid(fwd, lat, height, K, W, self.cfg)

        phrases = list(dict.fromkeys(targets + list(HAZARD_PHRASES)))
        detections = self.detector.detect(bgr, phrases)

        objects, vehicles = [], []
        for det in detections:
            is_target = det.phrase in targets
            is_vehicle = det.phrase in HAZARD_PHRASES
            loc = locate(scaled.depth, K, plane, det.box, with_footprint=is_target)
            if loc is None:
                continue
            if is_target:
                objects.append({
                    "label": det.phrase,
                    "score": round(det.score, 3),
                    "x_m": round(loc.x_m, 3),
                    "z_m": round(loc.z_m, 3),
                    "distance_m": round(loc.distance_m, 3),
                    "bearing_deg": round(loc.bearing_deg, 1),
                    "bottom_m": round(loc.bottom_m, 2),
                    "top_m": round(loc.top_m, 2),
                    "footprint": loc.footprint,
                })
            if is_vehicle:
                vehicles.append((HAZARD_PHRASES[det.phrase], det.box, loc.distance_m, loc.bearing_deg))
        objects.sort(key=lambda o: o["distance_m"])
        for i, obj in enumerate(objects):
            obj["id"] = i

        hazards = self.tracker.update(captured_at, vehicles)

        msg.update(
            latency_ms=int((time.time() - captured_at) * 1000),
            valid=True,
            status=_status("ok", "ok", scaled.source, scaled.lidar_status, scaled.lidar_range_m),
            grid={
                "rows": GRID_ROWS, "cols": GRID_COLS, "cell_m": CELL_M,
                "z_min_m": self.cfg.d_min, "x_min_m": -self.cfg.lateral_half_m,
                # 行 0 为最远，列 0 为最左（相机视角）
                "cells": ["".join("1" if v else "0" for v in row) for row in grid],
            },
            objects=objects,
            hazards=hazards,
        )
        return msg
