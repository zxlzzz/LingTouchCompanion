"""
眼镜端感知服务入口。

    python main.py --config config.json

启动后加载深度与检测模型、接入相机与激光雷达，持续处理最新一帧，
通过 WebSocket 把感知 JSON 推送给手机。
"""

import argparse
import asyncio
import json
import logging
import threading
import time
from pathlib import Path

import torch

from camera_source import WebSocketFrames, create_source
from depth_estimator import DepthEstimator
from hazard_tracker import HazardConfig
from lidar_tfs20l import TFS20L
from link_server import LinkServer
from object_detector import ObjectDetector
from perception import PerceptionPipeline, hello_message

HERE = Path(__file__).resolve().parent
NO_SIGNAL_AFTER_S = 2.0         # 超过此时长没有新画面视为相机无信号
NO_SIGNAL_REPORT_S = 1.0        # 无信号状态的上报间隔

log = logging.getLogger("glasses")


def resolve_device(name):
    if name == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return name


def perception_loop(source, pipeline, link, stop):
    last_t = 0.0
    last_report = 0.0
    while not stop.is_set():
        item = source.latest()
        now = time.time()
        if item is None or now - item[1] > NO_SIGNAL_AFTER_S:
            if now - last_report >= NO_SIGNAL_REPORT_S:
                link.publish(pipeline.no_signal_message())
                last_report = now
            stop.wait(0.05)
            continue
        bgr, t = item
        if t <= last_t:
            stop.wait(0.005)
            continue
        last_t = t
        try:
            msg = pipeline.process(bgr, t)
        except Exception:
            log.exception("感知处理出错，本帧丢弃")
            continue
        link.publish(msg)
        last_report = time.time()


def main():
    ap = argparse.ArgumentParser(description="灵触随行 眼镜端感知服务")
    ap.add_argument("--config", default=str(HERE / "config.json"))
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s", datefmt="%H:%M:%S")
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))

    device = resolve_device(cfg.get("device", "auto"))
    log.info("推理设备：%s", device)
    models = cfg["models"]
    depth = DepthEstimator(HERE / models["depth_checkpoint"], device)
    detector = ObjectDetector(HERE / models["detector_dir"], device,
                              models.get("box_threshold", 0.35), models.get("text_threshold", 0.25))

    lidar_cfg = cfg.get("lidar", {})
    lidar = None
    if lidar_cfg.get("enabled"):
        lidar = TFS20L(lidar_cfg["port"], lidar_cfg.get("baudrate", 115200),
                       lidar_cfg.get("min_strength", 100), lidar_cfg.get("max_age_s", 0.3)).start()
        log.info("激光雷达：%s", lidar_cfg["port"])

    source = create_source(cfg["camera"]).start()
    pipeline = PerceptionPipeline(
        depth, detector, lidar, cfg["camera"], cfg["wearing_height_m"],
        lidar_offset_px=tuple(lidar_cfg.get("offset_px", (0, 0))),
        hazard_cfg=HazardConfig(**cfg.get("hazard", {})),
    )

    server = cfg.get("server", {})
    link = LinkServer(server.get("host", "0.0.0.0"), server.get("port", 8770),
                      hello_message(), pipeline.set_targets,
                      frame_sink=source if isinstance(source, WebSocketFrames) else None)

    stop = threading.Event()
    worker = threading.Thread(target=perception_loop, args=(source, pipeline, link, stop),
                              name="perception", daemon=True)
    worker.start()
    try:
        asyncio.run(link.serve_forever())
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        source.stop()
        if lidar is not None:
            lidar.stop()


if __name__ == "__main__":
    main()
