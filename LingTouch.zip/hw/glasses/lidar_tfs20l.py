"""
北醒 TFS20-L 单点激光雷达串口驱动。

协议（UART，默认 115200 8N1）：
  数据帧 9 字节：59 59 Dist_L Dist_H Strength_L Strength_H Temp_L Temp_H Checksum
  距离单位 cm（标准 9 字节 cm 格式），Checksum 为前 8 字节累加和的低 8 位。
  配置命令：5A Len ID Payload Checksum，Checksum 为前 Len-1 字节累加和的低 8 位。
  每次上电需发送输出使能命令，数据才开始输出。
量程 0.2–20m（90% 反射率），光斑视场角 <2°。

后台线程持续读帧，latest() 返回最近一次有效测距；读数过期、信号强度不足或超出
量程时返回相应状态，由调用方回退到其他尺度来源。
"""

import threading
import time
from dataclasses import dataclass

import serial

FRAME_HEAD = 0x59
FRAME_LEN = 9
RANGE_MIN_M = 0.2
RANGE_MAX_M = 20.0
FOV_DEG = 2.0


def _command(cmd_id, payload=b""):
    body = bytes([0x5A, 4 + len(payload), cmd_id]) + payload
    return body + bytes([sum(body) & 0xFF])


CMD_OUTPUT_ENABLE = _command(0x07, b"\x01")   # 5A 05 07 01 67
CMD_FORMAT_CM = _command(0x05, b"\x01")       # 5A 05 05 01 65


@dataclass
class LidarReading:
    status: str             # ok | not_connected | out_of_range | error
    distance_m: float = None
    strength: int = 0
    timestamp: float = 0.0


class TFS20L:
    def __init__(self, port, baudrate=115200, min_strength=100, max_age_s=0.3):
        self.port = port
        self.baudrate = baudrate
        self.min_strength = min_strength
        self.max_age_s = max_age_s
        self._lock = threading.Lock()
        self._last = None               # (distance_m, strength, t)
        self._state = "not_connected"
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, name="tfs20l", daemon=True)

    def start(self):
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()

    def latest(self):
        now = time.monotonic()
        with self._lock:
            state, last = self._state, self._last
        if state != "ok":
            return LidarReading(status=state)
        if last is None or now - last[2] > self.max_age_s:
            return LidarReading(status="error")
        dist, strength, t = last
        if strength < self.min_strength or not (RANGE_MIN_M <= dist <= RANGE_MAX_M):
            return LidarReading(status="out_of_range", distance_m=dist, strength=strength, timestamp=t)
        return LidarReading(status="ok", distance_m=dist, strength=strength, timestamp=t)

    def _set_state(self, state):
        with self._lock:
            self._state = state

    def _run(self):
        while not self._stop.is_set():
            try:
                with serial.Serial(self.port, self.baudrate, timeout=0.2) as ser:
                    ser.write(CMD_FORMAT_CM)
                    ser.write(CMD_OUTPUT_ENABLE)
                    self._set_state("ok")
                    self._read_loop(ser)
            except serial.SerialException:
                self._set_state("not_connected")
                self._stop.wait(1.0)

    def _read_loop(self, ser):
        buf = bytearray()
        while not self._stop.is_set():
            chunk = ser.read(64)
            if not chunk:
                continue
            buf.extend(chunk)
            while len(buf) >= FRAME_LEN:
                if buf[0] != FRAME_HEAD or buf[1] != FRAME_HEAD:
                    del buf[0]
                    continue
                frame = bytes(buf[:FRAME_LEN])
                if (sum(frame[:8]) & 0xFF) != frame[8]:
                    del buf[0]
                    continue
                del buf[:FRAME_LEN]
                dist_cm = frame[2] | (frame[3] << 8)
                strength = frame[4] | (frame[5] << 8)
                with self._lock:
                    self._last = (dist_cm / 100.0, strength, time.monotonic())
