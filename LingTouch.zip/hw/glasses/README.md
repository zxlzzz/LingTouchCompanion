# 眼镜端感知服务

智能眼镜的端侧感知程序。单摄像头采集彩色画面，单点激光雷达提供测距，端侧 AI 完成深度估计与物体识别，感知结果以 JSON 经 WebSocket 传给手机，不传输视频。推理设备自动选择：有 CUDA 时使用 GPU（fp16），否则使用 CPU。

## 处理流程

```
相机画面 ──► 深度估计（Depth Anything V2 Metric, ViT-L）
            │
激光雷达 ──►  尺度锚定：雷达测距 / 佩戴高度（二选一，自动切换）
            │
            ▼
         地面拟合（RANSAC + 非对称迭代精修）──► 40cm 全局占用栅格（10×9）
            │
相机画面 ──► 开放词汇检测（Grounding DINO）：寻物目标词 + 来车类别
            │
            ├─► 寻物目标：三维位置、离地高度、5cm 占地轮廓
            └─► 车辆：跨帧跟踪，按距离变化率判断是否正在接近
            │
            ▼
       感知 JSON ──WebSocket──► 手机
```

| 文件 | 作用 |
|---|---|
| `main.py` | 服务入口：加载模型、接入相机与雷达、感知循环 |
| `camera_source.py` | 相机输入：USB 摄像头 / MJPEG 图像流 / WebSocket 帧推送 |
| `lidar_tfs20l.py` | 北醒 TFS20-L 单点激光雷达串口驱动 |
| `depth_estimator.py` | 单目米制深度估计 |
| `scale_anchor.py` | 深度尺度锚定（激光雷达 / 佩戴高度） |
| `ground_topdown.py` | 地面拟合与 40cm 俯视占用栅格 |
| `object_detector.py` | 开放词汇目标检测 |
| `object_locator.py` | 检测框 → 三维位置与 5cm 占地轮廓 |
| `hazard_tracker.py` | 来车跟踪与接近判定 |
| `perception.py` | 感知管线，生成感知 JSON |
| `link_server.py` | 与手机的 WebSocket 链路 |
| `download_models.py` | 下载模型权重 |
| `third_party/depth_anything_v2/` | 深度模型网络结构源码（Apache-2.0） |

### 尺度锚定

单目深度的绝对尺度随场景材质、光照漂移，每帧重新定尺度：

- **激光雷达**：雷达与相机光轴平行安装，取光斑覆盖像素区域（按雷达 2° 视场换算）的深度中位数，尺度 = 雷达测距 / 该中位数。
- **佩戴高度**：雷达未接入或读数无效（信号强度不足、超出 0.2–20m 量程、读数过期、尺度超出合理区间）时，先在原始深度上拟合地面得到相机离地高度，尺度 = 配置的佩戴高度 / 该高度。

两种方式得到的尺度都作用于整幅深度图，再重新拟合地面得到最终坐标系。当前使用的方式写在 `status.scale_source`。

### 全局占用栅格

地面坐标系下纵向 1–5m、横向 −1.8m–+1.8m，每格 40cm，共 10 行 × 9 列。离地 0.10–1.80m 的点计入所在格；每格阈值为"该格在当前距离上被障碍完全填满时应有的采样点数 × 3.5%"，并按格子在视场内的可见宽度折算，与图像分辨率无关。每列只保留最近的两个占用格，形成距离剖面。

### 来车检测

汽车（含公交、货车）、摩托车、自行车、电动车四类。检测框逐帧按 IoU 关联成轨迹，用最近 3 秒的距离观测拟合接近速度；接近速度 ≥ 2.5 m/s 且到达时间 ≤ 4 s 时上报。阈值高于步行速度，使用者自身前行造成的静止车辆"接近"不会触发。

### 地面不可见

画面中找不到足够的可见地面时，本帧输出 `valid: false`，只带状态，不带任何空间信息，由手机提示使用者，不会被当作前方通畅。

## 运行

1. 安装依赖（Python 3.10+；CUDA 版 PyTorch 按显卡驱动从 pytorch.org 选择安装命令）：

   ```sh
   pip install -r requirements.txt
   ```

2. 下载模型权重到 `models/`（默认经 hf-mirror.com，可用环境变量 `HF_ENDPOINT` 改为其他地址）：

   ```sh
   python download_models.py
   ```

3. 复制 `config.example.json` 为 `config.json` 并按实际设备修改，然后启动：

   ```sh
   python main.py --config config.json
   ```

   启动后监听 `ws://<本机IP>:8770/perception`，在手机 App 的"设置"中填入该地址。

## 配置

| 字段 | 说明 |
|---|---|
| `device` | `auto`（有 CUDA 用 GPU，否则 CPU）/ `cuda` / `cpu` |
| `wearing_height_m` | 相机佩戴高度（m），佩戴高度锚定时的基准 |
| `camera.source` | `usb` / `mjpeg` / `websocket` |
| `camera.usb_index`、`usb_width`、`usb_height` | USB 摄像头序号与采集分辨率 |
| `camera.mjpeg_url` | MJPEG 图像流地址 |
| `camera.rotate_deg` | 画面旋转 0/90/180/270，使画面上方朝上 |
| `camera.max_side_px` | 画面长边上限，超出时等比缩小 |
| `camera.fx_px`、`fx_ref_width_px` | 标定焦距（像素）及标定时的画面宽度，实际焦距按宽度等比换算 |
| `lidar.enabled`、`port`、`baudrate` | 激光雷达开关、串口、波特率 |
| `lidar.min_strength` | 信号强度下限，低于此值的读数不用于定尺度 |
| `lidar.max_age_s` | 读数有效期 |
| `lidar.offset_px` | 雷达光斑相对画面中心的像素偏移 |
| `models.*` | 模型路径与检测阈值 |
| `hazard.*` | 来车接近速度阈值、到达时间阈值、跟踪距离上限 |
| `server.host`、`port` | WebSocket 监听地址 |

`websocket` 相机源：图像流连接 `ws://<本机IP>:8770/camera`，每条二进制消息为一帧 JPEG。

## 感知 JSON

手机连接 `/perception` 后先收到：

```json
{"type": "hello", "version": 1, "hazard_labels": ["bicycle", "car", "electric_bike", "motorcycle"]}
```

之后每处理完一帧收到一条：

```json
{
  "type": "perception",
  "seq": 1024,
  "ts": 1790000000123,
  "latency_ms": 540,
  "valid": true,
  "status": {
    "camera": "ok",
    "depth": "ok",
    "lidar": "ok",
    "scale_source": "lidar",
    "lidar_range_m": 3.42
  },
  "grid": {
    "rows": 10, "cols": 9, "cell_m": 0.4, "z_min_m": 1.0, "x_min_m": -1.8,
    "cells": ["000000000", "000110000", "...", "000000000"]
  },
  "objects": [{
    "id": 0, "label": "chair", "score": 0.71,
    "x_m": -0.05, "z_m": 1.82, "distance_m": 1.82, "bearing_deg": -1.6,
    "bottom_m": 0.0, "top_m": 0.53,
    "footprint": {"cell_m": 0.05, "x0_m": -0.3, "z0_m": 1.6, "cols": 12, "rows": 8,
                  "cells": ["000111100000", "..."]}
  }],
  "hazards": [{
    "track_id": 3, "label": "car", "distance_m": 6.8, "bearing_deg": 25.0,
    "approach_mps": 4.0, "ttc_s": 1.7
  }]
}
```

| 字段 | 说明 |
|---|---|
| 坐标 | 以相机为原点投影到地面：`x` 向右为正（相机视角），`z` 向前为正，高度从地面算起，单位 m；`bearing_deg` 右为正 |
| `ts` | 画面采集时刻（ms） |
| `status.camera` | `ok` / `no_signal`（超过 2 秒没有新画面） |
| `status.depth` | `ok` / `ground_not_found` / `invalid` |
| `status.lidar` | `ok` / `not_connected` / `out_of_range` / `error` |
| `grid.cells` | 10 个字符串，行 0 最远（4.6–5.0m）、行 9 最近（1.0–1.4m），列 0 最左，`1` 为占用 |
| `objects` | 当前检测词对应的目标，按距离由近到远 |
| `objects[].bottom_m`、`top_m` | 目标最低、最高点离地高度，用于区分地面与台面上的物体 |
| `objects[].footprint` | 目标在地面上的 5cm 占地轮廓，`x0_m`/`z0_m` 为左、近边缘，`cells` 行 0 最远 |
| `hazards` | 正在接近的车辆，`ttc_s` 为按当前接近速度到达的时间 |

`valid` 为 `false` 时不带 `grid`、`objects`、`hazards`。

手机 → 眼镜：

```json
{"type": "query", "targets": ["red cup"]}
```

设置寻物检测词（英文名词短语），空数组为清除；所有手机断开后自动清除。

## 第三方模型

| 模型 | 用途 | 许可证 |
|---|---|---|
| Depth Anything V2 Metric Hypersim Large（depth-anything/Depth-Anything-V2-Metric-Hypersim-Large） | 米制深度估计 | 权重 CC-BY-NC-4.0，网络结构源码 Apache-2.0 |
| Grounding DINO Tiny（IDEA-Research/grounding-dino-tiny） | 开放词汇目标检测 | Apache-2.0 |
